package TestRunnerCucumber;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(tags="",features={"src/main/resources/Features"},glue= "BDDTest/stepDefinitions",
plugin= {"pretty","html:target/htmlreport.html"})
public class TestRunner extends AbstractTestNGCucumberTests {

}
